<?php
require 'config.php';
$base_dir = '../1.0.0.0';
$message = "";

if (isset($_POST['zip'])) {
  $zipname = $base_dir . '/' . trim($_POST['zip'], '/') . '.zip';
  $folder = $base_dir . '/' . trim($_POST['folder'], '/');
  $zip = new ZipArchive();
  if ($zip->open($zipname, ZipArchive::CREATE) === TRUE) {
    $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($folder), RecursiveIteratorIterator::LEAVES_ONLY);
    foreach ($files as $name => $file) {
      if (!$file->isDir()) {
        $filePath = $file->getRealPath();
        $zip->addFile($filePath, substr($filePath, strlen($folder) + 1));
      }
    }
    $zip->close();
    $message = "ZIP oluşturuldu: " . htmlspecialchars($_POST['zip']) . '.zip';
  }
}

if (isset($_POST['unzip'])) {
  $zip = new ZipArchive();
  $zfile = $base_dir . '/' . trim($_POST['unzip'], '/');
  if ($zip->open($zfile) === TRUE) {
    $zip->extractTo($base_dir);
    $zip->close();
    $message = "ZIP başarıyla açıldı.";
  }
}
?>
<!DOCTYPE html>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body { display: flex; margin: 0; }
.sidebar {
  width: 250px;
  height: 100vh;
  background: #343a40;
  color: white;
  position: fixed;
  left: 0;
  top: 0;
  padding-top: 20px;
}
.sidebar a {
  display: block;
  padding: 15px;
  color: white;
  text-decoration: none;
}
.sidebar a:hover {
  background: #495057;
}
.content {
  margin-left: 250px;
  padding: 30px;
  flex-grow: 1;
}
</style>
  <title>Zip İşlemleri</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<?php include "sidebar.php"; ?>
<div class="content">
<div class="container mt-4">
  <h2>🗜️ Zip İşlemleri</h2>
  <?php if ($message): ?><div class="alert alert-info"><?= $message ?></div><?php endif; ?>
  <form method="POST" class="mb-4">
    <input type="text" name="folder" class="form-control mb-2" placeholder="Hedef klasör (örnek: assets)" required>
    <input type="text" name="zip" class="form-control mb-2" placeholder="Zip adı (örnek: arsiv)">
    <button class="btn btn-success">ZIP Oluştur</button>
  </form>
  <form method="POST">
    <input type="text" name="unzip" class="form-control mb-2" placeholder="Zip dosya adı (örnek: arsiv.zip)" required>
    <button class="btn btn-warning">ZIP Çıkar</button>
  </form>
</div>
</div>
</body>
</html>
