<?php if (!isset($_SESSION)) session_start(); ?>
<div class="sidebar">
  <h4 class="text-center py-3">⚙ Admin Panel</h4>
  <a href="dashboard.php">🏠 Panel Anasayfa</a>
  <a href="upload.php">📁 Dosya Yükle</a>
  <a href="folders.php">📂 Klasör Yönetimi</a>
  <a href="zip.php">🗜️ Zip İşlemleri</a>
  <a href="users.php">👤 Kullanıcı Yönetimi</a>
  <a href="logout.php" class="text-danger">🚪 Çıkış</a>
</div>
