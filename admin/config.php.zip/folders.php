<?php
require 'config.php';
$base_dir = '../1.0.0.0';
$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $new_folder = $base_dir . '/' . trim($_POST['folder'], '/');
  if (!is_dir($new_folder)) {
    mkdir($new_folder, 0777, true);
    $message = "Klasör oluşturuldu: " . htmlspecialchars($_POST['folder']);
  } else {
    $message = "Klasör zaten var.";
  }
}
?>
<!DOCTYPE html>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body { display: flex; margin: 0; }
.sidebar {
  width: 250px;
  height: 100vh;
  background: #343a40;
  color: white;
  position: fixed;
  left: 0;
  top: 0;
  padding-top: 20px;
}
.sidebar a {
  display: block;
  padding: 15px;
  color: white;
  text-decoration: none;
}
.sidebar a:hover {
  background: #495057;
}
.content {
  margin-left: 250px;
  padding: 30px;
  flex-grow: 1;
}
</style>
  <title>Klasör Yönetimi</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<?php include "sidebar.php"; ?>
<div class="content">
<div class="container mt-4">
  <h2>📂 Klasör Oluştur</h2>
  <?php if ($message): ?><div class="alert alert-info"><?= $message ?></div><?php endif; ?>
  <form method="POST">
    <input type="text" name="folder" class="form-control mb-3" placeholder="örnek: yeni_klasor/alt_klasor" required>
    <button class="btn btn-primary">Klasör Oluştur</button>
  </form>
</div>
</div>
</body>
</html>
