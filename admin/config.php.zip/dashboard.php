<?php require 'config.php'; if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; } ?>
<!DOCTYPE html>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body { display: flex; margin: 0; }
.sidebar {
  width: 250px;
  height: 100vh;
  background: #343a40;
  color: white;
  position: fixed;
  left: 0;
  top: 0;
  padding-top: 20px;
}
.sidebar a {
  display: block;
  padding: 15px;
  color: white;
  text-decoration: none;
}
.sidebar a:hover {
  background: #495057;
}
.content {
  margin-left: 250px;
  padding: 30px;
  flex-grow: 1;
}
</style>
  <title>Admin Panel</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { display: flex; }
    .sidebar {
      width: 250px;
      height: 100vh;
      background: #343a40;
      color: white;
    }
    .sidebar a {
      display: block;
      padding: 15px;
      color: white;
      text-decoration: none;
    }
    .sidebar a:hover {
      background: #495057;
    }
    .content {
      flex-grow: 1;
      padding: 30px;
    }
  </style>
</head>
<body>
<?php include "sidebar.php"; ?>
<div class="content">
<div class="sidebar">
  <h4 class="text-center py-3">⚙ Admin Panel</h4>
  <a href="dashboard.php">🏠 Panel Anasayfa</a>
  <a href="upload.php">📁 Dosya Yükle</a>
  <a href="folders.php">📂 Klasör Yönetimi</a>
  <a href="zip.php">🗜️ Zip İşlemleri</a>
  <a href="users.php">👤 Kullanıcı Yönetimi</a>
  <a href="logout.php" class="text-danger">🚪 Çıkış</a>
</div>
<div class="content">
  <h1>Hoşgeldiniz!</h1>
  <p>Sol menüyü kullanarak işlemler yapabilirsiniz.</p>
</div>
</div>
</body>
</html>
