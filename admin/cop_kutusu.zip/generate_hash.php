<?php
$password = "Cankira.1";
$hash = password_hash($password, PASSWORD_DEFAULT);
echo "Şifrenin hash'i: " . $hash;
?>
