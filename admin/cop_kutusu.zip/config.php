<?php
$host = 'localhost';
$db = 'nuyacom_packadmin';
$user = 'nuyacom_packadmin';
$pass = 'SNooP.,456';

try {
  $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
  die("Veritabanı bağlantı hatası: " . $e->getMessage());
}
session_start();

function secure_password($password) {
  return password_hash($password, PASSWORD_DEFAULT);
}
?>