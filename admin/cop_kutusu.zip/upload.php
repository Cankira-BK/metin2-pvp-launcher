<?php
require 'config.php';
$base_dir = '../1.0.0.0';
$trash_dir = '../admin/cop_kutusu';
if (!is_dir($trash_dir)) mkdir($trash_dir, 0777, true);

$dir = isset($_GET['dir']) ? trim($_GET['dir'], '/') : '';
$upload_dir = $base_dir . ($dir ? '/' . $dir : '');
if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);

// Dosya yukleme
if (isset($_FILES['files'])) {
  foreach ($_FILES['files']['name'] as $index => $name) {
    $filename = basename($name);
    $tmp = $_FILES['files']['tmp_name'][$index];
    if (is_uploaded_file($tmp)) {
      move_uploaded_file($tmp, "$upload_dir/$filename");
    }
  }
}

// Zip cikarma
if (isset($_POST['unzip'])) {
  $zip_file = $upload_dir . '/' . basename($_POST['unzip']);
  $zip = new ZipArchive;
  if ($zip->open($zip_file) === TRUE) {
    $zip->extractTo($upload_dir);
    $zip->close();
  }
}

// Toplu islem (sil/kopyala/tasi/cop)
if (isset($_POST['bulk_action']) && isset($_POST['selected_items'])) {
  $action = $_POST['bulk_action'];
  $target_dir = isset($_POST['target_dir']) ? trim($_POST['target_dir'], '/') : $dir;
  $target_path = $base_dir . ($target_dir ? '/' . $target_dir : '');
  if (!is_dir($target_path)) mkdir($target_path, 0777, true);
  foreach ($_POST['selected_items'] as $item) {
    $src = "$upload_dir/" . basename($item);
    $dst = "$target_path/" . basename($item);
    $trash_path = "$trash_dir/" . ($dir ? "$dir/" : '') . basename($item);
    if (!is_dir(dirname($trash_path))) mkdir(dirname($trash_path), 0777, true);

    if ($action === 'delete') {
      if (is_file($src)) unlink($src);
      if (is_dir($src)) {
        $items = array_diff(scandir($src), ['.', '..']);
        foreach ($items as $subitem) {
          if (is_file("$src/$subitem")) unlink("$src/$subitem");
        }
        rmdir($src);
      }
    }
    elseif ($action === 'copy') {
      if (is_file($src)) copy($src, $dst);
    }
    elseif ($action === 'move') {
      rename($src, $dst);
    }
    elseif ($action === 'trash') {
      rename($src, $trash_path);
    }
  }
}

// Tekli silme (çöp kutusuna gönder)
if (isset($_POST['delete'])) {
  $target = $upload_dir . '/' . basename($_POST['delete']);
  $trash_path = "$trash_dir/" . ($dir ? "$dir/" : '') . basename($_POST['delete']);
  if (!is_dir(dirname($trash_path))) mkdir(dirname($trash_path), 0777, true);
  rename($target, $trash_path);
}

// Klasor olusturma
if (isset($_POST['new_folder'])) {
  $folder_name = preg_replace('/[^a-zA-Z0-9_-]/', '', $_POST['new_folder']);
  if ($folder_name) {
    mkdir("$upload_dir/$folder_name", 0777, true);
  }
}

$files = array_diff(scandir($upload_dir), ['.', '..']);
$relative = $dir ? $dir . '/' : '';
function buildBreadcrumb($dir) {
  $parts = explode('/', $dir);
  $path = '';
  $breadcrumbs = ['<a href="?">/</a>'];
  foreach ($parts as $part) {
    if (!$part) continue;
    $path .= ($path ? '/' : '') . $part;
    $breadcrumbs[] = "<a href=\"?dir=" . urlencode($path) . "\">" . htmlspecialchars($part) . "</a>";
  }
  return implode(' / ', $breadcrumbs);
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Dosya Yükle</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { display: flex; margin: 0; }
    .sidebar {
      width: 250px;
      height: 100vh;
      background: #343a40;
      color: white;
      position: fixed;
      left: 0;
      top: 0;
      padding-top: 20px;
    }
    .sidebar a {
      display: block;
      padding: 15px;
      color: white;
      text-decoration: none;
    }
    .sidebar a:hover {
      background: #495057;
    }
    .content {
      margin-left: 250px;
      padding: 30px;
      flex-grow: 1;
    }
    .folder { font-weight: bold; }
    .file-actions { display: flex; gap: 10px; align-items: center; }
  </style>
</head>
<body>
<?php include "sidebar.php"; ?>
<div class="content">
  <h2>📁 Dosya Yükle</h2>
  <div class="mb-3">
    <strong>Klasör Yolu:</strong> <?= buildBreadcrumb($dir) ?>
    <?php if ($dir): ?>
      <?php $parent = dirname($dir); ?>
      <a href="?dir=<?= urlencode($parent === '.' ? '' : $parent) ?>" class="btn btn-sm btn-secondary ms-3">⬅️ Geri</a>
    <?php endif; ?>
  </div>
  <form method="POST" enctype="multipart/form-data" class="mb-4">
    <div class="mb-2">
      <input type="file" name="files[]" class="form-control" multiple required>
      <input type="hidden" name="dir" value="<?= htmlspecialchars($dir) ?>">
    </div>
    <button class="btn btn-success">Yükle</button>
  </form>
  <form method="POST" class="mb-4 d-flex" style="gap: 10px;">
    <input type="text" name="new_folder" class="form-control" placeholder="Yeni klasör adı" required>
    <input type="hidden" name="dir" value="<?= htmlspecialchars($dir) ?>">
    <button class="btn btn-primary">Klasör Oluştur</button>
  </form>
  <form method="POST" class="mb-4">
    <input type="hidden" name="dir" value="<?= htmlspecialchars($dir) ?>">
    <div class="d-flex gap-2 align-items-center">
      <select name="bulk_action" class="form-select w-auto">
        <option value="">Toplu İşlem Seç</option>
        <option value="delete">Sil</option>
        <option value="copy">Kopyala</option>
        <option value="move">Taşı</option>
        <option value="trash">Çöp Kutusuna Gönder</option>
      </select>
      <input type="text" name="target_dir" placeholder="Hedef klasör" class="form-control w-auto">
      <button type="submit" class="btn btn-primary" onclick="return confirm('Seçilen işlem uygulanacak. Devam edilsin mi?')">Uygula</button>
    </div>
    <br>
    <table class="table">
      <thead>
        <tr>
          <th><input type="checkbox" onclick="document.querySelectorAll('input[name=\'selected_items[]\']').forEach(cb=>cb.checked=this.checked)"></th>
          <th>Ad</th>
          <th>İşlemler</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($files as $f): ?>
        <?php $path = "$upload_dir/$f"; ?>
        <tr>
          <td><input type="checkbox" name="selected_items[]" value="<?= htmlspecialchars($f) ?>"></td>
          <td>
            <?php if (is_dir($path)): ?>
              <a href="?dir=<?= urlencode($relative . $f) ?>" class="folder">📁 <?= htmlspecialchars($f) ?></a>
            <?php else: ?>
              <?= htmlspecialchars($f) ?>
            <?php endif; ?>
          </td>
          <td class="file-actions">
            <?php if (!is_dir($path) && strtolower(pathinfo($f, PATHINFO_EXTENSION)) === 'zip'): ?>
              <form method="POST">
                <input type="hidden" name="dir" value="<?= htmlspecialchars($dir) ?>">
                <button name="unzip" value="<?= htmlspecialchars($f) ?>" class="btn btn-sm btn-warning">Unzip</button>
              </form>
            <?php endif; ?>
            <form method="POST" action="upload.php" onsubmit="return confirm('Silmek istediğinize emin misiniz?');">
              <input type="hidden" name="dir" value="<?= htmlspecialchars($dir) ?>">
              <button type="submit" name="delete" value="<?= htmlspecialchars($f) ?>" class="btn btn-sm btn-danger">Çöp Kutusu</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </form>
</div>
</body>
</html>
