<?php
require 'config.php';
$message = "";

if (isset($_POST['newuser']) && isset($_POST['newpass'])) {
  $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
  $stmt->execute([$_POST['newuser'], secure_password($_POST['newpass'])]);
  $message = "Yeni kullanıcı oluşturuldu.";
}

if (isset($_POST['deleteuser'])) {
  $stmt = $pdo->prepare("DELETE FROM users WHERE username = ?");
  $stmt->execute([$_POST['deleteuser']]);
  $message = "Kullanıcı silindi.";
}
$users = $pdo->query("SELECT username FROM users")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body { display: flex; margin: 0; }
.sidebar {
  width: 250px;
  height: 100vh;
  background: #343a40;
  color: white;
  position: fixed;
  left: 0;
  top: 0;
  padding-top: 20px;
}
.sidebar a {
  display: block;
  padding: 15px;
  color: white;
  text-decoration: none;
}
.sidebar a:hover {
  background: #495057;
}
.content {
  margin-left: 250px;
  padding: 30px;
  flex-grow: 1;
}
</style>
  <title>Kullanıcı Yönetimi</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<?php include "sidebar.php"; ?>
<div class="content">
<div class="container mt-4">
  <h2>👤 Kullanıcı Yönetimi</h2>
  <?php if ($message): ?><div class="alert alert-info"><?= $message ?></div><?php endif; ?>
  <form method="POST" class="mb-4">
    <input type="text" name="newuser" class="form-control mb-2" placeholder="Yeni kullanıcı adı" required>
    <input type="password" name="newpass" class="form-control mb-2" placeholder="Şifre" required>
    <button class="btn btn-primary">Kullanıcı Ekle</button>
  </form>
  <h4>Mevcut Kullanıcılar</h4>
  <ul class="list-group">
  <?php foreach ($users as $u): ?>
    <li class="list-group-item d-flex justify-content-between">
      <?= htmlspecialchars($u['username']) ?>
      <form method="POST">
        <button name="deleteuser" value="<?= htmlspecialchars($u['username']) ?>" class="btn btn-sm btn-danger">Sil</button>
      </form>
    </li>
  <?php endforeach; ?>
  </ul>
</div>
</div>
</body>
</html>
